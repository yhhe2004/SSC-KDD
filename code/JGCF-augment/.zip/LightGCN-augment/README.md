

# LightGCN

[[official-code](https://github.com/gusye1234/LightGCN-PyTorch)]


## Usage

Run with full-ranking

    python main.py --config=configs/xxx.yaml --ranking=full

or with sampled-based ranking

    python main.py --config=configs/xxx.yaml --ranking=pool